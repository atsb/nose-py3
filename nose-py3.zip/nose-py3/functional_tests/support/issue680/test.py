# coding: utf-8
def test_foo():
    print(u"abc€")
