def test_is_generator_alias():
    pass
