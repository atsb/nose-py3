boodle = True


def somefunc():
    """This is a doctest in somefunc.
    >>> 'a'
    'a'
    """
