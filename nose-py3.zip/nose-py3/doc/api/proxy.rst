.. automodule :: nose.proxy
:members: