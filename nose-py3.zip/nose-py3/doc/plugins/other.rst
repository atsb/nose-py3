Third-party nose plugins
------------------------

Visit http://nose-plugins.jottit.com/ for a list of third-party nose plugins
compatible with nose 0.9 through 0.11. If you have released a plugin that you
don't see in the list, please add it!
